using Command;

public class UnitMoveState : IUnitState
{
    private Tile targetTile;

    public UnitMoveState(Tile target)
    {
        targetTile = target;
    }

    public void Enter(Unit unit)
    {
        //Debug.Log($"{unit.UnitName} entered Move State");
        ICommand moveCommand = new MoveCommand(unit, targetTile);
        CommandInvoker.Instance.SetCommand(moveCommand);
    }

    public void Execute(Unit unit)
    {
        // ���� ���� �̵� �������� ������ �� ����
    }

    public void Exit(Unit unit)
    {
        CommandInvoker.Instance.ClearCommand();
        unit.GetComponent<UnitStateController>().IsBusy = false;
    }
}
