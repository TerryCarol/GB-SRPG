using Command;
using System.Collections.Generic;
using System.Xml.Linq;
using UnityEngine;
using static UnityEngine.UI.CanvasScaler;

/*
public class UnitIdleState : IUnitState
{
    private UnitStateController controller;
    private List<Tile> movableTiles;
    public void Enter(Unit unit)
    {
        // ���� ���� ��
        //Debug.Log($"{unit.UnitName} entered Idle State");

        controller = unit.GetComponent<UnitStateController>();
        controller.IsBusy = false;

        Tile originTile = unit.GetUnitTile();
        if(unit.GetMovableTiles(originTile) != null)
        {
            movableTiles = unit.GetMovableTiles(originTile);
        }
        else
        {
            // ����
            EndTurn();
            return;
        }
    }

    public void Execute(Unit unit)
    {
        // ���� ����� �� ã��
        Unit closestEnemy = FindClosestEnemy(unit);
        if (closestEnemy == null)
        {
            EndTurn();
            return;
        }

        // Chebyshev �Ÿ� (�밢���� 1Ÿ�� ���)
        float distanceToEnemy = Mathf.Max(
            Mathf.Abs(unit.currentPos.x - closestEnemy.currentPos.x),
            Mathf.Abs(unit.currentPos.y - closestEnemy.currentPos.y)
        );

        // ���� ��Ÿ� �̳� �� �߰� -> AttackState ����
        if (distanceToEnemy <= unit.AttackRange)
        {
            controller.ChangeState(new UnitAttackState(closestEnemy));
            return;
        }

        // ó�� ��ġ �������� �̵� ������ Ÿ�� ������ �� ����
        if (movableTiles == null || movableTiles.Count == 0)
        {
            EndTurn();
            return;
        }

        // �� ��ó�� �̵��� ���� Ÿ�� ã��
        Tile targetTile = FindClosestTileTowards(closestEnemy.GetUnitTile(), movableTiles);

        if (targetTile != null)
        {
            if (controller != null)
            {
                controller.ChangeState(new UnitMoveState(targetTile));
            }
            else
            {
                EndTurn();
            }
        }
        else
        {
            EndTurn();
        }
        // UnitApproachState�� �и� �ʿ�?
        // UnitPatrolState �ʿ�
    }

    public void Exit(Unit unit)
    {
        unit.GetComponent<UnitStateController>().IsBusy = false;
    }

    private void EndTurn()
    {
        if (controller != null)
            controller.IsBusy = false; // �� ���� ��ȣ
    }

    private Unit FindClosestEnemy(Unit self)
    {
        Unit[] allUnits = GameObject.FindObjectsOfType<Unit>();
        Unit closestEnemy = null;
        float closestDistance = float.MaxValue;

        foreach (var other in allUnits)
        {
            if (other == self) continue;
            if (other.Health <= 0f) continue;
            if (other.Faction == self.Faction) continue;

            float dist = Vector2Int.Distance(self.currentPos, other.currentPos);
            if (dist < closestDistance)
            {
                closestDistance = dist;
                closestEnemy = other;
            }
        }

        return closestEnemy;
    }
    private Tile FindClosestTileTowards(Tile target, List<Tile> tiles)
    {
        Tile closestTile = null;
        float closestDistance = float.MaxValue;

        foreach (var tile in tiles)
        {
            float dist = Vector2Int.Distance(tile.gridPos, target.gridPos);
            if (dist < closestDistance)
            {
                closestDistance = dist;
                closestTile = tile;
            }
        }

        return closestTile;
    }
}
*/

public class UnitIdleState : IUnitState
{
    public void Enter(Unit unit)
    {

    }

    public void Execute(Unit unit)
    {
        var controller = unit.GetComponent<UnitStateController>();
        if (controller == null) return;
        else if (controller != null)
        {
            //controller.IsBusy = false;

            if (unit.ActionPoints <= 0)
            {
                // �ൿ���� ������ �� ����
                Debug.Log($"{unit.UnitName}�� �ൿ���� ��� ������. �� ����.");
                controller.IsBusy = false; // ���������� �� �� ��
                return;
            }
            else
            {
                // �ൿ���� �������� �ൿ ����
            }
        }

        // 1. ���� ����� �� Ž��
        Unit closestEnemy = FindClosestEnemy(unit);
        if (closestEnemy == null)
        {
            controller.IsBusy = false; // �ƹ� ���� ������ �׳� �� ����
            return;
        }

        // 2. ������ �Ÿ� ��� (�밢�� �����ؼ� 1ĭ ������ ���)
        int dx = Mathf.Abs(unit.currentPos.x - closestEnemy.currentPos.x);
        int dy = Mathf.Abs(unit.currentPos.y - closestEnemy.currentPos.y);
        int distance = Mathf.Max(dx, dy); // �밢���� 1ĭ���� ���

        // 3. ���� ��Ÿ� ���̸� ���� �õ�
        if (distance <= unit.AttackRange)
        {
            controller.ChangeState(new UnitAttackState(closestEnemy));
            return;
        }

        // 4. �̵��� �� �ִ� Ÿ�� ���
        Tile originTile = unit.GetUnitTile();
        if (originTile == null)
        {
            controller.IsBusy = false;
            return;
        }

        List<Tile> movableTiles = unit.GetMovableTiles(originTile);
        Tile targetTile = FindClosestTileTowards(closestEnemy.GetUnitTile(), movableTiles);

        if (targetTile != null)
        {
            controller.ChangeState(new UnitMoveState(targetTile));
            return;
        }
        else
        {
            controller.IsBusy = false; // �̵��� Ÿ���� ������ �׳� �� ����
        }

        controller.IsBusy = true;
    }

    public void Exit(Unit unit)
    {
        CommandInvoker.Instance.ClearCommand();
        // ���¿��� ���� �� Ư���� �� �۾� ����
    }

    private Unit FindClosestEnemy(Unit self)
    {
        Unit[] allUnits = GameObject.FindObjectsOfType<Unit>();
        Unit closestEnemy = null;
        float closestDistance = float.MaxValue;

        foreach (var other in allUnits)
        {
            if (other == self) continue;
            if (other.Health <= 0f) continue;
            if (other.Faction == self.Faction) continue;

            float dist = Vector2Int.Distance(self.currentPos, other.currentPos);
            if (dist < closestDistance)
            {
                closestDistance = dist;
                closestEnemy = other;
            }
        }

        return closestEnemy;
    }

    private Tile FindClosestTileTowards(Tile target, List<Tile> tiles)
    {
        Tile closestTile = null;
        float closestDistance = float.MaxValue;

        foreach (var tile in tiles)
        {
            float dist = Vector2Int.Distance(tile.gridPos, target.gridPos);
            if (dist < closestDistance)
            {
                closestDistance = dist;
                closestTile = tile;
            }
        }

        return closestTile;
    }
}
