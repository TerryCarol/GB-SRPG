using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class UnitStateController : MonoBehaviour
{
    private IUnitState currentState;
    private Unit unit;
    public bool IsBusy = false;

    void Awake()
    {
        unit = GetComponent<Unit>();

        //currentState = new UnitIdleState();
        //currentState.Enter(unit);
    }


    public Unit GetUnitData()
    {
        return unit;
    }

    public void ExecuteTurn()
    {
        currentState.Execute(unit); // ���� ���¿��� �� �ൿ ����
    }

    public void ChangeState(IUnitState newState)
    {
        currentState?.Exit(unit);
        currentState = newState;
        currentState.Enter(unit);
    }
}

