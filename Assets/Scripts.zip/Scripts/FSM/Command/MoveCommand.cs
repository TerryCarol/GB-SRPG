using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

namespace Command
{
    public class MoveCommand : ICommand
    {
        private Unit unit;
        private Tile targetTile;

        public MoveCommand(Unit unit, Tile targetTile)
        {
            this.unit = unit;
            this.targetTile = targetTile;
        }

        public void Execute()
        {
            var controller = unit.GetComponent<UnitStateController>();
            if(controller != null)
            {
                if (unit.HasEnoughActionPoints(1))
                {
                    controller.IsBusy = true;
                    unit.MoveTo(targetTile);
                }
                else
                {
                    Debug.Log($"{unit.UnitName}�� �̵��� �ൿ���� ������.");
                    controller.IsBusy = false;
                    controller.ChangeState(new UnitIdleState()); // �ٽ� Idle��}
                }
            }
        }
    }
}
