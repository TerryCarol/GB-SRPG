using UnityEngine;
using static UnityEngine.UI.CanvasScaler;

namespace Command
{
    public class AttackCommand : ICommand
    {
        private Unit attacker;
        private Unit target;
        private System.Action onComplete;

        public AttackCommand(Unit attacker, Unit target, System.Action onComplete = null)
        {
            this.attacker = attacker;
            this.target = target;
            this.onComplete = onComplete;
        }

        public void Execute()
        {
            if (attacker.HasEnoughActionPoints(1))
            {
                //target.Health -= attacker.AttackPower;
                
                // ȸ�� (���� �ٶ󺸰�)
                Vector3 dir = (target.transform.position - attacker.transform.position).normalized;
                if (dir != Vector3.zero)
                    attacker.transform.forward = dir;

                Animator animator = attacker.GetComponentInChildren<Animator>();

                if (attacker.AttackRange <= 1f)
                {
                    // ���� ����
                    if (animator != null) animator.SetTrigger("Melee");

                    // Ÿ�̹� ���� ������ ó�� (����: 0.4�� ��)
                    attacker.StartCoroutine(ApplyDelayedDamage(0.4f));
                }
                else
                {
                    // ���Ÿ� ����
                    if (animator != null) animator.SetTrigger("Shoot");

                    attacker.StartCoroutine(ApplyDelayedDamage(0.2f));
                }

                attacker.UseActionPoint(1); // ���� �� �ൿ�� 1 ���
            }
            else
            {
                UnityEngine.Debug.Log($"{attacker.UnitName}�� ������ �ൿ���� ������.");
                onComplete?.Invoke();
            }
        }

        // ������ ���� ������ �Լ�
        private System.Collections.IEnumerator ApplyDelayedDamage(float delay)
        {
            yield return new UnityEngine.WaitForSeconds(delay);
            ApplyDamage();

            // ���� �Ϸ� �ݹ� ȣ��
            onComplete?.Invoke();
        }

        // ��� ���� ������ �Լ�
        private void ApplyDamage()
        {
            if (target != null && target.Health > 0)
            {
                target.Health -= attacker.AttackPower;
                

                if (target.Health <= 0)
                {
                    var controller = target.GetComponent<UnitStateController>();
                    if (controller != null)
                    {
                        controller.ChangeState(new UnitDeathState(attacker.transform));
                        UnityEngine.Debug.Log($"{attacker.UnitName} Killed {target.UnitName} with {attacker.AttackPower} damage.");
                    }
                }
                else
                {
                    UnityEngine.Debug.Log($"{attacker.UnitName} attacked {target.UnitName} with {attacker.AttackPower} damage.");
                }
            }
        }
    }
}
