using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Command;
using UnityEditor.Experimental.GraphView;

public class UnitDeathState : IUnitState
{
    private Transform attacker;

    public UnitDeathState(Transform attacker = null)
    {
        this.attacker = attacker;
    }

    public void Enter(Unit unit)
    {
        ICommand deathCommand = new DeathCommand(unit, attacker);
        CommandInvoker.Instance.SetCommand(deathCommand);
    }

    public void Execute(Unit unit)
    {
        // �׾����� (�ƹ��͵� ������?)
    }

    public void Exit(Unit unit)
    {
        CommandInvoker.Instance.ClearCommand();
    }
}

