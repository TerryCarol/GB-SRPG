using Command;

public class UnitAttackState : IUnitState
{
    private Unit target;

    public UnitAttackState(Unit target)
    {
        this.target = target;
    }

    public void Enter(Unit unit)
    {
        //Debug.Log($"{unit.UnitName} entered Attack State");

        var controller = unit.GetComponent<UnitStateController>();

        ICommand attackCommand = new AttackCommand(unit, target, () =>
        {
            // ���� �Ϸ� �� ���� ��ȯ
            controller.ChangeState(new UnitIdleState());
        });

        CommandInvoker.Instance.SetCommand(attackCommand);
    }

    public void Execute(Unit unit)
    {
        
    }

    public void Exit(Unit unit)
    {
        CommandInvoker.Instance.ClearCommand();
        var controller = unit.GetComponent<UnitStateController>();
        controller.IsBusy = false;
    }
}

