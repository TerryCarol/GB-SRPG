using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIManager : MonoBehaviour
{
    private List<UnitStateController> aiUnits = new List<UnitStateController>();
    private int currentIndex = 0;
    private bool isAITurn = false;

    void Awake()
    {
        aiUnits = new List<UnitStateController>();
    }
    void Start()
    {
        //aiUnits.AddRange(FindObjectsOfType<UnitStateController>());
    }

    public void StartAITurn()
    {
        aiUnits.Clear();
        aiUnits.AddRange(FindObjectsOfType<UnitStateController>());

        /*
        foreach (var unit in aiUnits)
        {
            Debug.Log($"[AI ��� Ȯ��] {unit.name} / Faction: {unit.GetUnitData().Faction}, AIControl: {unit.GetUnitData().AIControl}");
        }
        */

        // AI���� ���ֵ� AP �ʱ�ȭ
        foreach (var unitController in aiUnits)
        {
            var unit = unitController.GetUnitData();
            if ((unit.Faction == Faction.Enemy || unit.AIControl) && unit.Health > 0f)
            {
                unit.ResetActionPoints();
            }
        }

        if (aiUnits.Count == 0)
        {
            Debug.LogWarning("AIManager: No AI units found this turn.");
            isAITurn = false;
            TurnManager.Instance.EndEnemyTurn();
            return;
        }

        currentIndex = 0;
        isAITurn = true;
    }

    void Update()
    {
        if (!isAITurn) return;

        if (currentIndex < aiUnits.Count)
        {
            UnitStateController unitController = aiUnits[currentIndex];

            if (unitController == null || unitController.GetUnitData() == null)
            {
                currentIndex++;
                return;
            }

            var unit = unitController.GetUnitData();

            // Enemy�̰ų� AIControl ������ ���ָ� ����
            if ((unit.Faction == Faction.Enemy || unit.AIControl) && unit.Health > 0f)
            {
                // ���� ���� ���̸� ���
                if (!unitController.IsBusy)
                {
                    if (unit.ActionPoints > 0)
                    {
                        unitController.ExecuteTurn(); // ���� ���� �� busy
                        return;
                    }
                    else
                    {
                        currentIndex++;               // ���� �������� �Ѿ
                        return;
                    }
                }
                return;
            }
            currentIndex++;
        }
        else
        {
            Debug.Log("AI �� ����");
            isAITurn = false;
            TurnManager.Instance.EndEnemyTurn();
        }
    }
}

