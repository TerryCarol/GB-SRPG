using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Pathfinder
{
    private GridManager gridManager;
    private BFS bfs;
    private Vector2Int startTile, targetTile;

    public Pathfinder(GridManager gridManager)
    {
        this.gridManager = gridManager;
        this.bfs = new BFS(gridManager);            // BFS �ν��Ͻ� ����
    }

    public List<Tile> FindPath(Tile start, Tile target)
    {
        startTile = start.gridPos;                  // BFS�� 2���� int �迭�� ����
        targetTile = target.gridPos;                
        return bfs.FindPath(startTile, targetTile); // BFS�� ��ã�� �޼��� ȣ��
    }

    public List<Tile> FindReachableTiles(Tile start, float maxRange)
    {
        return bfs.FindReachableTiles(start.gridPos, maxRange);
    }
}
