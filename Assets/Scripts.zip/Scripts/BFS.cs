using System.Collections.Generic;
using UnityEngine;

public class BFS
{
    private GridManager gridManager;

    public BFS(GridManager gridManager)
    {
        this.gridManager = gridManager;
    }

    // BFS ��ã�� �޼���
    public List<Tile> FindPath(Vector2Int start, Vector2Int goal)
    {
        Queue<Vector2Int> queue = new Queue<Vector2Int>();
        Dictionary<Vector2Int, Vector2Int> cameFrom = new Dictionary<Vector2Int, Vector2Int>();

        queue.Enqueue(start);
        cameFrom[start] = start;

        while (queue.Count > 0)
        {
            Vector2Int current = queue.Dequeue();

            if (current == goal)
            {
                break; // ��ǥ ������ �����ϸ� ����
            }

            foreach (Vector2Int next in GetNeighbors(current))
            {
                Tile nextTile = gridManager.GetTileAtPosition(next);
                if (!cameFrom.ContainsKey(next) &&          // ���� Ÿ�ϰ� ���� X
                    nextTile.isWalkable &&                  // ���� ���� O
                    !nextTile.isOccupied)                 // �̹� ���� X
                {
                    queue.Enqueue(next);
                    cameFrom[next] = current;
                }
            }
        }

        return ReconstructPath(cameFrom, start, goal);
    }

    // �־��� �������� �� �� �ִ� ���� Ÿ�ϵ��� ��ȯ
    // �ڳ�Ŀ�ù��� ���� ���� IsDiagonalMoveValid Ȯ�� �߰�
    private List<Vector2Int> GetNeighbors(Vector2Int current)
    {
        List<Vector2Int> neighbors = new List<Vector2Int>();

        // 8���� (�����¿� + �밢�� ����)
        Vector2Int[] directions = new Vector2Int[]
        {
            new Vector2Int(0, 1),   // ��
            new Vector2Int(0, -1),  // ��
            new Vector2Int(1, 0),   // ��
            new Vector2Int(-1, 0),  // ��
            new Vector2Int(1, 1),   // ��
            new Vector2Int(-1, 1),  // ��
            new Vector2Int(1, -1),  // ��
            new Vector2Int(-1, -1)  // ��
        };

        foreach (Vector2Int dir in directions)
        {
            Vector2Int neighbor = current + dir;
            
            if (gridManager.GetTileAtPosition(neighbor) != null)
            {
                if (!IsDiagonalMoveValid(current, neighbor)) continue;

                neighbors.Add(neighbor);
            }
        }

        return neighbors;
    }

    // ��� �籸�� (cameFrom�� ��������)
    private List<Tile> ReconstructPath(Dictionary<Vector2Int, Vector2Int> cameFrom, Vector2Int start, Vector2Int goal)
    {
        List<Tile> path = new List<Tile>();
        Vector2Int current = goal;

        while (current != start)
        {
            path.Add(gridManager.GetTileAtPosition(current));
            current = cameFrom[current];
        }

        path.Add(gridManager.GetTileAtPosition(start));
        path.Reverse();
        return path;
    }

    private bool IsDiagonalMoveValid(Vector2Int from, Vector2Int to)
    {
        Vector2Int diff = to - from;
        if (Mathf.Abs(diff.x) == 1 && Mathf.Abs(diff.y) == 1) // �밢�� Ÿ�� �̵��̸�
        {
            Vector2Int neighbor1 = new Vector2Int(from.x + diff.x, from.y);    // �밢�� X+1 ���� �̿�
            Vector2Int neighbor2 = new Vector2Int(from.x, from.y + diff.y);    // �밢�� Y+1 ���� �̿�

            Tile tile1 = gridManager.GetTileAtPosition(neighbor1);
            Tile tile2 = gridManager.GetTileAtPosition(neighbor2);

            if ((tile1 != null && !tile1.isWalkable) || (tile2 != null && !tile2.isWalkable))
            {
                return false; // �� �� �ϳ��� �� �������� �밢�� ��
            }
        }

        return true;
    }

    public List<Tile> FindReachableTiles(Vector2Int start, float maxRange)
    {
        List<Tile> reachable = new List<Tile>();
        Queue<Vector2Int> frontier = new Queue<Vector2Int>();
        Dictionary<Vector2Int, float> costSoFar = new Dictionary<Vector2Int, float>();

        frontier.Enqueue(start);
        costSoFar[start] = 0;

        while (frontier.Count > 0)
        {
            Vector2Int current = frontier.Dequeue();
            float currentCost = costSoFar[current];

            foreach (Vector2Int nextPos in GetNeighbors(current))
            {
                Tile neighbor = gridManager.GetTileAtPosition(nextPos);
                if (neighbor == null || !neighbor.isWalkable || neighbor.isOccupied)
                    continue;

                if (costSoFar.ContainsKey(nextPos)) continue;

                float newCost = currentCost + 1;
                if (newCost <= maxRange)
                {
                    costSoFar[nextPos] = newCost;
                    frontier.Enqueue(nextPos);
                    reachable.Add(neighbor);
                }
            }
        }

        return reachable;
    }
}
