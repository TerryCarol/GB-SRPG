using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TopDownCameraController : MonoBehaviour
{
    public float rotationAngle = 45f;   // ī�޶� �¿� ȸ�� ����
    public float moveSpeed = 10f;       // ī�޶� WASD �̵� �ӵ�

    public float edgeMoveSpeed = 10f;   // ���콺�����ڸ� ī�޶� �̵� �ӵ�
    public int edgeSize = 10;           // �̵����� ȭ�鰡���ڸ� ���� �β�

    private void Start()
    {
        transform.rotation = Quaternion.Euler(45f, 0f, 0f);
    }

    void Update()
    {
        HandleKeyboardMovement();
        HandleRotation();
        HandleZoom();

        //HandleEdgeMovement();
    }

    void HandleKeyboardMovement()
    {
        float h = Input.GetAxisRaw("Horizontal"); // A, D
        float v = Input.GetAxisRaw("Vertical");   // W, S

        Vector3 moveDir = new Vector3(h, 0, v).normalized;

        // ���� ī�޶��� ���� �������� �̵�
        Vector3 worldMove = transform.TransformDirection(moveDir);
        worldMove.y = 0f; // Y�� ����

        transform.position += worldMove * moveSpeed * Time.deltaTime;
    }

    void HandleRotation() // Q, E�� ī�޶� 45���� ȸ�� (XCOM ��Ÿ��)
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            RotateCamera(rotationAngle);
        }
        else if (Input.GetKeyDown(KeyCode.E))
        {
            RotateCamera(-rotationAngle);
        }
    }

    void RotateCamera(float angle)
    {
        transform.RotateAround(transform.position, Vector3.up, angle);
    }

    [SerializeField] private float zoomSpeed = 100f;
    [SerializeField] private float minHeight = 10f;
    [SerializeField] private float maxHeight = 100f;

    private void HandleZoom()
    {
        float scroll = Input.GetAxis("Mouse ScrollWheel");

        if (Mathf.Abs(scroll) > 0.01f)
        {
            Vector3 zoomDirection = transform.forward;

            // Ȯ��/��Ҵ� Y�� ��ġ�θ� ����
            float newY = transform.position.y + -scroll * zoomSpeed * Time.deltaTime;

            if (newY >= minHeight && newY <= maxHeight)
            {
                transform.position += zoomDirection * scroll * zoomSpeed * Time.deltaTime;
            }
        }
    }


    void HandleEdgeMovement() // ���콺Ŀ���� ȭ�� �����ڸ��� ���� �� �������� ī�޶� �̵�
    {
        Vector3 move = Vector3.zero;
        Vector3 mousePos = Input.mousePosition;

        if (mousePos.x < edgeSize) move.x = -1;
        else if (mousePos.x > Screen.width - edgeSize) move.x = 1;

        if (mousePos.y < edgeSize) move.z = -1;
        else if (mousePos.y > Screen.height - edgeSize) move.z = 1;

        Vector3 worldMove = transform.TransformDirection(move.normalized);
        worldMove.y = 0f;

        transform.position += worldMove * edgeMoveSpeed * Time.deltaTime;
    }
}
