using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitSelector : MonoBehaviour
{
    public GridManager gridManager;
    public GameObject playerPrefab;

    private Unit hoveredUnit;
    private Unit previousUnit;

    void Update()
    {
        HandleMouseHover();
    }

    void HandleMouseHover()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hit))
        {
            Unit unit = hit.collider.GetComponent<Unit>();
            if (unit != null)
            {
                if (unit != hoveredUnit)
                {
                    // ���� ���� ���̶���Ʈ ����
                    if (previousUnit != null)
                    {
                        previousUnit.ResetHighlight();
                    }

                    hoveredUnit = unit;
                    hoveredUnit.Highlight(Color.white, true);
                    previousUnit = hoveredUnit;
                }
            }
        }
        else
        {
            // ���콺�� �ƹ� ���ֿ��� ���� ���� ��� ���̶���Ʈ ����
            if (previousUnit != null)
            {
                previousUnit.ResetHighlight();
                previousUnit = null;
                hoveredUnit = null;
            }
        }
    }
}
