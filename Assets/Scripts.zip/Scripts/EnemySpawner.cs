using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public UnitFactory unitFactory;
    public float spawnInterval = 0.1f;
    public bool spawnerIsOn = true;
    public float nextSpawnTime = 1f;

    public int spawnerUnitLimit = 10;
    private int spawnedUnitCount = 0;
    private GridManager gridManager;

    void Start()
    {
        gridManager = FindObjectOfType<GridManager>();  // GridManager�� ã��
        nextSpawnTime = Time.time + spawnInterval;
    }

    private void Update()
    {
        if (spawnerIsOn && Time.time >= nextSpawnTime)
        {
            SpawnEnemy();
            nextSpawnTime = Time.time + spawnInterval;
        }
    }

    void SpawnEnemy()
    {
        while(spawnedUnitCount < spawnerUnitLimit)
        {
            // �����ϰ� ������ ����
            string unitType = GetRandomUnitType();
            Debug.Log($"Trying to spawn {unitType}");

            Unit unit = unitFactory.CreateUnit(unitType);
            unit.AIControl = true;

            if (unit != null)
            {
                // 1. �糡�� ���� ����Ʈ �� �ϳ��� ����
                //Vector2Int[] spawnPoints = gridManager.GetSpawnPoints();
                //Vector2Int spawnPosition2D = spawnPoints[Random.Range(0, spawnPoints.Length)];

                // 2. �׸���� ���� ���� ���� ����
                List<Tile> validTiles = gridManager.GetAllFreeWalkableTiles();

                // 2. ��� ����
                if (validTiles.Count > 0)
                {
                    Tile tile = validTiles[Random.Range(0, validTiles.Count)];
                    Vector3 spawnPosition = tile.transform.position + Vector3.up * 1.1f;

                    unit.transform.position = spawnPosition;
                    unit.Place(tile);

                    Debug.Log($"{unitType} spawned at {tile.gridPos}");

                    var controller = unit.GetComponent<UnitStateController>();
                    if (controller != null)
                    {
                        controller.ChangeState(new UnitIdleState());
                    }

                    spawnedUnitCount++;
                }
                else
                {
                    Destroy(unit.gameObject);
                    Debug.LogWarning("No valid tiles to spawn the unit.");
                    spawnerIsOn = false;
                }

                // 1. ��� ���� (��Ȱ��ȭ)
                /*
                Tile tile = gridManager.GetTileAtPosition(spawnPosition2D);

                if (tile != null && tile.isWalkable && !tile.isOccupied && spawnPoints.Length > 0)
                {
                    // ���� ����Ʈ�� Vector2Int���� Vector3�� ��ȯ
                    Vector3 spawnPosition = new Vector3(spawnPosition2D.x * gridManager.gridSize, 1.1f, spawnPosition2D.y * gridManager.gridSize);

                    // ������ �ش� ��ġ�� ����
                    unit.transform.position = spawnPosition;
                    unit.Place(tile);
                    Debug.Log($"{unitType} spawned at {spawnPosition2D}");

                    var controller = unit.GetComponent<UnitStateController>();
                    if (controller != null)
                    {
                        controller.ChangeState(new UnitIdleState());
                    }
                    spawnedUnitCount++;

                    return;
                }
                else
                {
                    Destroy(unit.gameObject);

                    if (tile.isOccupied)
                    {
                        Debug.Log($"{unitType} cannot be spawned. Spawnpoint is already occupied.");
                    }
                    else if (!tile.isWalkable)
                    {
                        Debug.Log($"{unitType} cannot be spawned. Spawnpoint is not passable terrain.");
                    }

                    // ��������Ʈ ������ Ƚ������ ���� ���� �� ������ �۵� ����
                    if(spawnedUnitCount >= 2)
                    {
                        spawnerIsOn = false;
                        Debug.Log("Turning off spawner.");
                    }
                }
                */
            }
            else
            {
                Debug.LogError("Error: Failed to spawn unit.");
            }
        }
    }

    string GetRandomUnitType()
    {
        // ������������ �ٸ��� ������ �����ϵ��� ����
        // ���÷� ���� ���� ����
        string[] unitTypes = { "Gunner", "Bruiser" };
        return unitTypes[Random.Range(0, unitTypes.Length)];
    }
}
