using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnManager : MonoBehaviour
{
    public static TurnManager Instance { get; private set; }

    private Faction currentFaction = Faction.Player;

    public bool IsPlayerTurn() => currentFaction == Faction.Player;
    public bool IsEnemyTurn() => currentFaction == Faction.Enemy;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    private void Start()
    {
        StartPlayerTurn();
    }

    public void EndPlayerTurn()
    {
        Debug.Log("�÷��̾� �� ����.");
        currentFaction = Faction.Enemy;
        StartEnemyTurn();
    }

    public void EndEnemyTurn()
    {
        Debug.Log("�� �� ����.");
        currentFaction = Faction.Player;
        StartPlayerTurn();
    }

    public void StartPlayerTurn()
    {
        Debug.Log("�÷��̾� �� ����.");
        currentFaction = Faction.Player;

        foreach (var unit in FindObjectsOfType<Unit>())
        {
            if (unit.Faction == Faction.Player)
            {
                unit.ResetActionPoints();
            }
        }
    }

    public void StartEnemyTurn()
    {
        Debug.Log("�� �� ����.");
        currentFaction = Faction.Enemy;

        AIManager aiManager = FindObjectOfType<AIManager>();
        if(aiManager != null)
        {
            aiManager.StartAITurn(); // AI FSM
        }
        else
        {
            Debug.LogError("Error: AIManager Missing");
        }
    }
}