using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using static UnityEngine.UI.CanvasScaler;
public enum UnitState
{
    // State ���ϱ��� Ȯ���غ� ��
    Idle,
    Moving,
    Attacking,
    Dying
}

public enum Faction
{
    Player,
    Enemy,
    Ally,
    Neutral
}

public class Unit : MonoBehaviour
{
    public Tile currentTile;
    public Renderer meshRenderer;
    public Vector2Int currentPos;

    private Animator animator;

    [SerializeField] private GameObject ragdollRoot;
    public GameObject RagdollRoot => ragdollRoot;
    public bool IsCorpse { get; set; }
    public UnitState CurrentState
    {
        get => currentState;
        set => currentState = value;
    }


    [SerializeField] private bool aiControl = false;
    [SerializeField] private Faction faction;
    [SerializeField] private Gender gender;
    [SerializeField] private string unitType;
    [SerializeField] private string unitName;
    [SerializeField] private float health = 100f;
    [SerializeField] private float attackPower = 10f;
    [SerializeField] private float attackRange = 1f;
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float moveRange = 6f;

    // ���� ����
    public bool AIControl
    {
        get => aiControl;
        set => aiControl = value;
    }
    public Faction Faction
    {
        get => faction;
        set => faction = value;
    }
    public Gender Gender
    {
        get => gender;
        set => gender = value;
    }
    public string UnitType
    {
        get => unitType;
        set => unitType = value;
    }
    public string UnitName
    {
        get => unitName;
        set => unitName = value;
    }

    public float Health
    {
        get => health;
        set => health = value;
    }

    public float AttackPower
    {
        get => attackPower;
        set => attackPower = value;
    }

    public float AttackRange
    {
        get => attackRange;
        set => attackRange = value;
    }

    public float MoveSpeed
    {
        get => moveSpeed;
        set => moveSpeed = value;
    }

    public float MoveRange
    {
        get => moveRange;
        set => moveRange = value;
    }

    private UnitStateController stateController;
    private UnitState currentState = UnitState.Idle;    // ���� STATE

    public PathVisualizer pathVisualizer;
    private Pathfinder pathfinder;                      // ��ã�� ��ũ��Ʈ
    private List<Tile> path = new List<Tile>();         // ��ã�� ����Ʈ
    private int currentPathIndex = 0;                   // ��ã�� �ε���
    private Vector3 lastPosition;
    private Color originalColor;

    void Awake()
    {
        stateController = GetComponent<UnitStateController>();
        pathVisualizer = GetComponentInChildren<PathVisualizer>();
        ResetActionPoints();

        // ������ �� ���� ��Ƽ���� ���� ����
        if (meshRenderer == null)
        {
            meshRenderer = GetComponentInChildren<Renderer>();
        }
        if (meshRenderer != null)
        {
            originalColor = meshRenderer.material.color;
        }
    }

    private void Start()
    {
        animator = GetComponentInChildren<Animator>();
        Debug.Log($"�ִϸ�����: {animator}, ��Ʈ�ѷ�: {animator.runtimeAnimatorController}");

        if (pathfinder == null)
        {
            GridManager gm = FindObjectOfType<GridManager>();
            pathfinder = new Pathfinder(gm);
            if (pathfinder == null)
            {
                Debug.LogError("Error : Pathfinder Not found");
            }
        }

        lastPosition = transform.position;

        if (pathVisualizer != null)
        {
            var factionData = FactionManager.GetData(this.faction);
            if (factionData != null)
            {
                pathVisualizer.SetColors(factionData.FactionColor);
            }
        }
        //highlightRing.GetComponent<Renderer>().material.color = this.Faction.color;

        IsCorpse = false;
    }

    [SerializeField] private float smoothArrivalThreshold = 0.01f;  // ���� ���� �Ÿ�
    // �� ������ ��ε��� ���� ���� �̵�
    void Update()
    {
        if (path.Count > 0 && currentPathIndex < path.Count)
        {
            //ShowPath(path);
            Tile targetTile = path[currentPathIndex];

            // �̵� �� ��� Ÿ���� ������ ��� �ߴ�
            if (targetTile != null && (!targetTile.isWalkable || (targetTile.isOccupied && targetTile.GetOnTileUnit() != this)))
            {
                Debug.LogWarning($"{UnitName} �̵� �� ��� �ҽ�. �̵� �ߴ�.");
                EndMovement();
                return;
            }

            Vector3 targetPosition = targetTile.transform.position + Vector3.up * 0.5f;  // Ÿ���� ��ġ�� �̵�

            // Ÿ�Ϸ� ������ �̵�
            currentState = UnitState.Moving;
            Vector3 direction = (targetPosition - transform.position).normalized;
            if (direction != Vector3.zero)
            {
                transform.forward = Vector3.Lerp(transform.forward, direction, 10f * Time.deltaTime);  // �ε巯�� ȸ��
            }

            // �� �̵� ��� (MoveToward)
            //transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);

            // ���� �̵� ��� (Lerp ����)
            float distanceToTarget = Vector3.Distance(transform.position, targetPosition);
            bool isFinalTile = currentPathIndex == path.Count - 1;
            float slowDownThreshold = 0.5f; // ���� �Ÿ� �Ӱ谪 ����
            float speedFactor = isFinalTile ? Mathf.Clamp01(distanceToTarget / slowDownThreshold) : 1f; // ������ Ÿ���̸� ����
            float adjustedSpeed = moveSpeed * speedFactor;

            transform.position = Vector3.MoveTowards(transform.position, targetPosition, adjustedSpeed * Time.deltaTime);

            // Ÿ�Ͽ� ����, �ش� Ÿ���� ���� Ÿ�Ϸ� ����
            if (distanceToTarget < smoothArrivalThreshold)
            {
                Place(targetTile);
                currentPathIndex++;

                if (currentPathIndex >= path.Count)
                {
                    EndMovement();
                }
            }
        }
        else if (path.Count <= 0 && currentState == UnitState.Moving)
        {
            EndMovement();
        }

        // ������Ʈ ���� �ӵ� ��� �� �ִϸ����Ϳ� ����
        float actualSpeed = ((transform.position - lastPosition).magnitude) / Time.deltaTime;
        animator.SetFloat("Speed", actualSpeed, 0.2f, Time.deltaTime);

        lastPosition = transform.position;

        if (CurrentState == UnitState.Moving)
        {
            ShowPathDuringMove();
        }
    }

    private void EndMovement()
    {
        currentState = UnitState.Idle;
        this.pathVisualizer.ClearPath();
        path.Clear();
        currentPathIndex = 0;

        if (stateController != null)
        {
            stateController.IsBusy = false;
            stateController.ChangeState(new UnitIdleState());
        }
    }

    // ������ Ÿ��(��ġ)���� ������Ʈ
    public void Place(Tile tile)
    {
        if (currentTile != null)
        {
            currentTile.ResetOnTileUnit();
            currentTile.isOccupied = false;
        }

        currentTile = tile;
        currentPos = tile.gridPos; // ���� Ÿ�� ��ġ�� ����
        transform.position = tile.transform.position + Vector3.up * 0.5f;   // Ÿ�� ���� ��¦ ����
        tile.isOccupied = true;
        tile.SetOnTileUnit(this);

        if (pathfinder == null)
        {
            GridManager gm = FindObjectOfType<GridManager>();
            pathfinder = new Pathfinder(gm);
        }
    }

    // ���� �̵��� ��� ��� ��û
    public void MoveTo(Tile tile)
    {
        if (currentState != UnitState.Idle)
        {
            Debug.LogWarning("Error: �̹� �̵����Դϴ�. �̵��Ϸ� �� �ٽ� �����ϼ���.");
            return;                                                         // �Ϸ� �� �� �ٸ� �̵����� ����
        }

        if (!HasEnoughActionPoints(1))
        {
            Debug.Log($"{unitName}�� �ൿ���� �����ؼ� �̵��� �� ����.");
            return;
        }

        if (!tile.isOccupied && tile.isWalkable)
        {
            List<Tile> testPath = pathfinder.FindPath(currentTile, tile);
            int testPathLength = testPath.Count - 1;

            if (testPath == null || testPath.Count == 0)                            
            {
                Debug.LogWarning("Error: ��θ� ã�� �� �����ϴ�.");        // ��ã�� ���� ����ó��
                return;
            }
            else if (testPathLength > moveRange)                            // ���ֽ��� �̵��� Ȯ��
            {
                Debug.LogWarning($"Error: ���� �̵� �Ÿ� �ʰ�. ({testPathLength} > {moveRange})");
                return;
            }

            if (!UseActionPoint(1))
            {
                Debug.Log($"{unitName}�� �ൿ���� �Ҹ����� ������.");
                return;
            }

            path = testPath;                                                // ���� �̵� Update�� �Է�
            currentPathIndex = 0;
            currentState = UnitState.Moving;                                // �̵� ���·� ��ȯ
        }
    }

    public GameObject highlightRing;
    public void Highlight(Color color, bool isOn)
    {
        /*
        Renderer childRenderer = GetComponentInChildren<Renderer>();
        if (childRenderer != null)
        {
            childRenderer.material.color = color;
        }
        */

        if (highlightRing != null)
        {
            highlightRing.GetComponent<Renderer>().material.color = color;
            highlightRing.SetActive(isOn);
        }
        else
        {
            return;
        }
    }

    public void ResetHighlight()
    {
        /*
        if (meshRenderer != null)
        {
            meshRenderer.material.color = originalColor;
        }
        */

        if (highlightRing != null)
        {
            highlightRing.SetActive(false);
        }
        else
        {
            return;
        }

    }

    public Tile GetUnitTile()
    {
        if (currentTile == null)
        {
            Debug.Log("Error: Unit's currentTile is set to Null");
        }
        return currentTile;
    }

    public List<Tile> GetMovableTiles(Tile origin = null)
    {
        Tile start = origin ?? currentTile;
        if (start == null)
        {
            Debug.Log("Error: GetMovableTiles NullReference occured");
            return null;
        }
        else
        {
            return pathfinder.FindReachableTiles(start, moveRange);
        }
    }

    [SerializeField] private int maxActionPoints = 2;
    [SerializeField] private int currentActionPoints;

    public int MaxActionPoints
    {
        get => maxActionPoints;
        set => maxActionPoints = value;
    }
    public int ActionPoints => currentActionPoints;

    public void ResetActionPoints()
    {
        currentActionPoints = maxActionPoints;
    }

    public bool UseActionPoint(int amount)
    {
        if (currentActionPoints >= amount)
        {
            currentActionPoints -= amount;
            return true;
        }
        return false;
    }

    public bool HasEnoughActionPoints(int amount)
    {
        return currentActionPoints >= amount;
    }

    public void ShowPath(List<Tile> fullPath)
    {
        if (pathVisualizer != null && fullPath != null && fullPath.Count > currentPathIndex)
        {
            List<Tile> remainingPath = fullPath.GetRange(currentPathIndex, fullPath.Count - currentPathIndex);
            pathVisualizer.DrawPath(remainingPath);
        }
    }

    public void ClearPath()
    {
        if (pathVisualizer != null)
            pathVisualizer.ClearPath();
    }

    private void ShowPathDuringMove()
    {
        if (pathVisualizer == null || currentPathIndex >= path.Count)
            return;

        // 1. ���� ���� <=> ���� Ÿ��
        Tile nextTile = path[currentPathIndex];
        Vector3 from = transform.position + Vector3.up * 0.01f;
        Vector3 to = nextTile.transform.position + Vector3.up * 0.51f;
        pathVisualizer.DrawSegment(from, to);

        // 2. ���� ��ü ���
        List<Tile> remaining = path.GetRange(currentPathIndex, path.Count - currentPathIndex);
        pathVisualizer.DrawPath(remaining);
    }
}
